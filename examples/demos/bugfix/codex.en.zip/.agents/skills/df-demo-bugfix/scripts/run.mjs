import { readFile, writeFile, rename, mkdir, rm, open, readdir } from 'node:fs/promises';
import { resolve, join, dirname, isAbsolute } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { runtime, requestJev } from './adapter.mjs';
const exec = promisify(execFile);
const skillRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const hash = text => createHash('sha256').update(text).digest('hex');
export async function save(path, data) { const temp = path + '.' + randomUUID() + '.tmp'; await writeFile(temp, JSON.stringify(data, null, 2) + '\n', { mode: 0o600 }); await rename(temp, path); }
export async function loadInstance(folder) {
  const definition = await readFile(join(folder, 'definition.json'), 'utf8');
  const machine = JSON.parse(definition), record = await json(join(folder, 'state-record.json')), session = await json(join(folder, 'session.json'));
  runtime.assertRecord(machine, record, hash(definition));
  return { machine, record, session };
}
async function locked(folder, action) {
  const path = join(folder, '.lock'); let lock;
  try { lock = await open(path, 'wx', 0o600); } catch (e) { if (e.code === 'EEXIST') throw new Error('The instance is being updated. Retry later without repeating business work.'); throw e; }
  try { return await action(); } finally { await lock.close(); await rm(path, { force: true }); }
}
async function emit(folder, record, type, detail, actor) {
  const event = { id: randomUUID(), at: new Date().toISOString(), type, stateId: record.currentState, actor, detail };
  await writeFile(join(folder, 'events.jsonl'), JSON.stringify(event) + '\n', { flag: 'a', mode: 0o600 });
}
async function archive(folder, record, session, reason) {
  if (session.archivedAt) return;
  session.archivedAt = new Date().toISOString(); session.archiveReason = reason; session.phase = record.status === 'completed' ? 'completed' : 'archived'; session.paused = false; session.stepBudget = 0;
  await save(join(folder, 'session.json'), session);
  await rm(join(dirname(folder), '.active', record.instanceId + '.json'), { force: true });
  await emit(folder, record, 'run.archived', reason, session.actor);
}
function settings(machine) { return machine.visualization || { enabled: true, autoOpen: true }; }
async function browser(url) {
  try {
    if (process.platform === 'win32') await exec('rundll32.exe', ['url.dll,FileProtocolHandler', url], { timeout: 5000 });
    else if (process.platform === 'darwin') await exec('open', [url], { timeout: 5000 });
    else if (process.env.WSL_DISTRO_NAME || /microsoft/i.test(await readFile('/proc/version', 'utf8').catch(() => ''))) {
      await exec('/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', 'Start-Process "' + url + '"'], { timeout: 5000 });
    } else await exec('xdg-open', [url], { timeout: 5000 });
    return true;
  } catch { return false; }
}
async function monitor(folder, machine, session, force = false, noOpen = false) {
  const config = session.visualization || settings(machine);
  if (!config.enabled && !force) return { visualization: 'disabled' };
  const file = join(folder, 'monitor.json'); let info;
  try { const existing = await json(file); if (!/^http:\/\/127\.0\.0\.1:\d+$/.test(existing.origin) || !/^[a-f0-9]{64}$/.test(existing.token)) throw new Error('Invalid viewer connection information'); const response = await fetch(existing.origin + '/snapshot', { headers: { 'X-DecoupleFlow-Run-Token': existing.token }, signal: AbortSignal.timeout(1000) }); if (response.ok && (await response.json()).record.instanceId === session.instanceId) info = existing; } catch {}
  if (!info) {
    // Each instance owns its monitor. Detached monitors expire after completion or inactivity.
    const lockPath = join(folder, '.monitor-lock'); let lock;
    try { lock = await open(lockPath, 'wx', 0o600); } catch (e) { if (e.code !== 'EEXIST') throw e; }
    if (lock) {
      try {
        await rm(file, { force: true });
        const child = spawn(process.execPath, [join(skillRoot, 'scripts/monitor.mjs'), folder], { detached: true, stdio: 'ignore', windowsHide: true });
        child.on('error', () => {}); child.unref();
        for (let i = 0; i < 50; i++) { try { info = await json(file); break; } catch { await new Promise(r => setTimeout(r, 100)); } }
      } finally { await lock.close(); await rm(lockPath, { force: true }); }
    } else { for (let i = 0; i < 50; i++) { try { info = await json(file); break; } catch { await new Promise(r => setTimeout(r, 100)); } } }
    if (!info) return { visualization: 'unavailable', warning: 'The live window could not start. Instance records are saved. Retry with view.' };
  }
  const url = info.origin + '/#' + info.token;
  const opened = config.autoOpen && !noOpen ? await browser(url) : false;
  return { visualization: 'ready', viewerUrl: url, browserOpened: opened, ...(!opened && config.autoOpen && !noOpen ? { warning: 'The system could not open a browser. Open viewerUrl.' } : {}) };
}
export async function runCommand(args) {
  const command = args[0];
  const arg = name => { const at = args.indexOf(name); return at < 0 ? undefined : args[at + 1]; };
  if (!['start', 'resume', 'view', 'status', 'event', 'advance', 'control', 'archive', 'fork', 'list'].includes(command)) throw new Error('Usage: run.mjs start --workspace <task-directory> | resume/view/status/event/advance/archive/fork --instance <instance-directory> | list --workspace <task-directory>');
  if (command === 'start' || command === 'list') {
    if (!arg('--workspace') || !isAbsolute(arg('--workspace'))) throw new Error('--workspace requires the absolute path of the current task workspace.');
    const text = await readFile(join(skillRoot, 'references/state-machine.json'), 'utf8');
    const machine = JSON.parse(text), manifest = await json(join(skillRoot, 'decoupleflow-manifest.json'));
    if (hash(text) !== manifest.semanticHash) throw new Error('The Skill definition does not match its manifest. Export it again.');
    const base = join(arg('--workspace'), '.decoupleflow', machine.id);
    if (command === 'list') {
      const names = await readdir(base).catch(() => []), instances = [];
      for (const name of names) { try { const s = await json(join(base, name, 'session.json')); instances.push({ ...s, instance: join(base, name) }); } catch {} }
      return { instances: instances.sort((a, b) => b.createdAt.localeCompare(a.createdAt)) };
    }
    const id = randomUUID(), folder = join(base, id), record = runtime.initialRecord(machine, hash(text), id);
    const visualization = { ...settings(machine) };
    if (arg('--visualization')) { if (!['on', 'off'].includes(arg('--visualization'))) throw new Error('--visualization accepts only on or off.'); visualization.enabled = arg('--visualization') === 'on'; }
    const session = { instanceId: id, machineId: machine.id, createdAt: new Date().toISOString(), actor: (arg('--actor') || 'Host Agent').slice(0, 120), visualization, phase: 'running', paused: false, stepBudget: 0 };
    await mkdir(join(base, '.active'), { recursive: true }); await mkdir(folder);
    await writeFile(join(folder, 'definition.json'), text, { mode: 0o600 });
    await writeFile(join(folder, 'state-machine.md'), await readFile(join(skillRoot, 'references/state-machine.md')), { mode: 0o600 });
    await save(join(folder, 'state-record.json'), record); await save(join(folder, 'session.json'), session);
    await save(join(base, '.active', id + '.json'), { instance: folder, instanceId: id });
    await emit(folder, record, 'run.started', 'Host invoked the Skill and created a new instance.', session.actor);
    await emit(folder, record, 'state.entered', runtime.getState(machine, record.currentState).name, session.actor);
    return { instance: folder, record, handoff: runtime.handoff(machine, record, ''), ...await monitor(folder, machine, session, false, args.includes('--no-open')) };
  }
  const folder = arg('--instance'); if (!folder || !isAbsolute(folder)) throw new Error('--instance requires the absolute instance directory returned by start.');
  if (['status', 'resume', 'view'].includes(command)) {
    const { machine, record, session } = await loadInstance(folder);
    if (record.status === 'completed' && !session.archivedAt) await archive(folder, record, session, 'Instance completed; finishing archive');
    if (command === 'resume' && (session.archivedAt || record.status === 'completed')) throw new Error('This instance is archived and read-only. Use start for a new task.');
    return { instance: folder, record, session, handoff: record.status === 'completed' ? null : runtime.handoff(machine, record, ''), ...(command === 'status' ? {} : await monitor(folder, machine, session, command === 'view', args.includes('--no-open'))) };
  }
  if (command === 'fork') return locked(folder, async () => {
    const { machine, record, session } = await loadInstance(folder);
    if (record.status === 'completed' || session.archivedAt) throw new Error('Archived instances are read-only. Use start to run again from the entry.');
    const id = randomUUID(), child = join(dirname(folder), id), next = { ...record, instanceId: id };
    const childSession = { ...session, instanceId: id, createdAt: new Date().toISOString(), forkedFrom: record.instanceId, paused: false, stepBudget: 0 };
    await mkdir(child); await writeFile(join(child, 'definition.json'), await readFile(join(folder, 'definition.json'))); await writeFile(join(child, 'state-machine.md'), await readFile(join(folder, 'state-machine.md')));
    await save(join(child, 'state-record.json'), next); await save(join(child, 'session.json'), childSession); await mkdir(join(dirname(folder), '.active'), { recursive: true }); await save(join(dirname(folder), '.active', id + '.json'), { instance: child, instanceId: id });
    await emit(child, next, 'run.forked', 'Forked from ' + record.instanceId + '; the host must explicitly resume this instance.', session.actor);
    return { instance: child, record: next, ...await monitor(child, machine, childSession, true, args.includes('--no-open')) };
  });
  return locked(folder, async () => {
    const { machine, record, session } = await loadInstance(folder);
    if (session.archivedAt || record.status === 'completed') { await archive(folder, record, session, 'Instance completed'); if (command === 'archive') return { record, session }; throw new Error('This instance is archived and cannot be changed. Use start for new tasks or view for history.'); }
    if (command === 'archive') { await archive(folder, record, session, 'Host ended this instance'); return { record, session }; }
    if (command === 'control') {
      const action = arg('--action'); if (!['pause', 'continue', 'step'].includes(action)) throw new Error('Unknown control action.');
      session.paused = action !== 'continue'; session.stepBudget = action === 'step' ? 1 : 0;
      await save(join(folder, 'session.json'), session); await emit(folder, record, 'run.' + action, action === 'step' ? 'Allow the next host transition, then remain paused.' : action === 'pause' ? 'Further transitions are paused. The host manages external business work.' : 'Allow the host to continue submitting transitions.', session.actor);
      return { record, session };
    }
    if (command === 'event') {
      const event = JSON.parse(arg('--event-json') || await readFile(arg('--event'), 'utf8'));
      if (!['agent.started', 'agent.completed', 'external.waiting', 'external.completed', 'human.required', 'run.failed', 'run.timeout'].includes(event.type)) throw new Error('Unknown event type.');
      const detail = String(event.detail || '').slice(0, 4000);
      session.phase = event.type === 'external.waiting' ? 'waiting' : event.type === 'human.required' ? 'human' : event.type === 'run.failed' ? 'failed' : event.type === 'run.timeout' ? 'timeout' : 'running';
      if (event.type === 'external.waiting') record.pendingExternalTask = { detail, actor: session.actor };
      else if (event.type === 'external.completed') record.pendingExternalTask = null;
      await save(join(folder, 'state-record.json'), record); await save(join(folder, 'session.json'), session);
      await emit(folder, record, event.type, detail, session.actor); return { record, session };
    }
    if (session.paused && !session.stepBudget) return { status: 'paused', reason: 'Instance paused. Keep current results and wait for continue or step before submitting again. Do not repeat business work.', record };
    const context = arg('--context') ? await readFile(arg('--context'), 'utf8') : '';
    if (context.length > 100000) throw new Error('Current evidence exceeds 100000 characters.');
    const driver = runtime.settings(machine); let result;
    await emit(folder, record, 'guard.started', driver.type === 'jev' ? 'Jev is checking current evidence.' : 'Checking the path and quality conclusions submitted by the host.', session.actor);
    try {
      if (driver.type === 'jev') result = runtime.interpretJev(machine, record, context, await requestJev(runtime.buildJevRequest(machine, record, context), process.env.TYPESAFE_API_KEY || ''), record.definitionHash);
      else { if (!arg('--decision')) throw new Error('Agent mode requires --decision <current-decision-json-file>.'); result = runtime.applyDecision(machine, record, JSON.parse(await readFile(arg('--decision'), 'utf8')), record.definitionHash); }
      if (session.stepBudget) session.stepBudget--;
      session.phase = result.status === 'held' ? (runtime.getState(machine, record.currentState).kind === 'wait' ? 'waiting' : 'human') : result.status === 'completed' ? 'completed' : runtime.getState(machine, result.record.currentState).kind === 'wait' ? 'waiting' : 'running';
      await save(join(folder, 'result.json'), result); await save(join(folder, 'state-record.json'), result.record); await save(join(folder, 'session.json'), session);
      await emit(folder, result.record, 'guard.evaluated', result.reason, driver.type === 'jev' ? 'Jev' : session.actor);
      if (result.status !== 'held') {
        if (result.record.history.at(-1)?.itemId) await emit(folder, result.record, 'list.item.passed', result.reason, session.actor);
        else { await emit(folder, result.record, 'transition.taken', record.currentState + ' → ' + result.record.currentState, session.actor); await emit(folder, result.record, result.status === 'completed' ? 'run.completed' : 'state.entered', runtime.getState(machine, result.record.currentState).name, session.actor); }
      }
      if (result.status === 'completed') await archive(folder, result.record, session, 'Completion of the top-level end state confirmed');
      return { ...result, instance: folder, handoff: result.status === 'completed' ? null : runtime.handoff(machine, result.record, '') };
    } catch (error) { await emit(folder, record, 'guard.failed', error.message, session.actor); throw error; }
  });
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  try { process.stdout.write(JSON.stringify(await runCommand(process.argv.slice(2)), null, 2) + '\n'); }
  catch (e) { process.stderr.write(e.message + '\n'); process.exitCode = 1; }
}
