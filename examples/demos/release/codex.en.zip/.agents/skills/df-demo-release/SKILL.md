---
name: df-demo-release
description: "Use the Release readiness state machine to locate the current state, check transitions and quality conditions, and maintain task state. Use when the user asks to start or resume this workflow."
metadata:
  generator: "DecoupleFlow"
  decoupleflow-id: "demo-release"
  decoupleflow-version: "1.0.0"
---

# Release readiness

This is a state machine module for an existing agent. Read the state descriptions, use your existing capabilities to do the work, and maintain correct transitions using actual evidence.

## Read the definition first

- [State machine document](references/state-machine.md): the complete Mermaid state diagram, states, transition conditions, quality checks, and node policies.
- [Structured definition](references/state-machine.json): state IDs, hierarchy, and transition references.
- [Tagged description](references/state-machine.xml): a structured text view of the same definition.
- [State record template](assets/state-record.template.json): the record format for the current task.

## On every invocation

- Read [Instances and live visualization](references/execution.md) first. Create this instance with `scripts/run.mjs start --workspace <absolute-task-workspace>`. When visualization is enabled, a live window opens automatically. Report actual events and submit transitions through the helper so the display matches the record.
- Always use start for a new task. Use resume with the original instance directory only when the user explicitly continues an unfinished task. Completed instances are archived automatically and must not be reused for new tasks. Do not write task state into the Skill installation directory.
- Read the returned handoff for the current goal, entry conditions, quality checks, tools, and policies. Perform work using host capabilities, then submit current evidence and condition conclusions in decisionFormat. Record only check results, evidence references, and a brief rationale.
- Keep the current state when conditions cannot be confirmed; verify or wait according to policy. Explain conflicting conditions or missing paths. Do not treat unknown conditions as passed.
- Acceptance by an external tool does not mean completion. Keep the original task ID and query that task before taking further action. Do not submit duplicates after a timeout. If automatic wake-up is unavailable, record pending work and resume explicitly later.
- Enter subflows through __enter__ and return through __return__ before checking parent paths. A top-level end state is archived after __finish__ confirms completion. Use the candidates returned by the helper. Definitions are pinned in the instance directory; do not silently replace an active version.

## Decisions and loops

Decision and loop nodes support multiple incoming and outgoing paths. On each arrival, use the arrival path and current context to evaluate outgoing paths under the node selection policy. A transition requires its condition, required quality items, and target entry conditions to pass. Stay when nothing matches or evidence is uncertain. If several paths match, follow the explicit selection policy; verify or clarify when it does not resolve the choice.

Use loopRole=continue to enter an iteration, then follow a defined return path to the loop node and check this iteration again. Use loopRole=exit to leave. Record actual transitions and iteration results. Never reuse a previous iteration’s passing result as current evidence.

## List states

Process the list in order. Recheck the shared pass condition and this state’s required quality checks for each item; stay on the current item if it fails or is uncertain. Check exit conditions only after all items pass. Pause and resume preserve the current item; reentering this state starts from the first item.

Read handoff.listProgress for the current item. Submit only its candidate ID returned by the helper (starting with __item__). Each advance confirms one item with evidence specific to that item. After the last item passes, read the exit candidates and check their conditions; passing the list does not automatically leave the state.

## Capability boundaries

The Skill provides instructions and state-record conventions. Tool connections, permissions, and background scheduling are supplied by the host. Explain any missing tools or materials, and follow existing host and user instructions.
