import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { runtime, requestJev } from './adapter.mjs';
const args = process.argv.slice(2);
const arg = name => { const at = args.indexOf(name); return at >= 0 ? args[at + 1] : undefined; };
try {
  const definition = await readFile(new URL('../references/state-machine.json', import.meta.url), 'utf8');
  const machine = JSON.parse(definition);
  const hash = createHash('sha256').update(definition).digest('hex');
  if (!arg('--record') || !arg('--context')) throw new Error('用法：node scripts/decide.mjs --record /path/record.json --context /path/evidence.txt');
  const record = JSON.parse(await readFile(arg('--record'), 'utf8'));
  const context = await readFile(arg('--context'), 'utf8');
  runtime.assertRecord(machine, record, hash);
  if (runtime.settings(machine).type !== 'jev') throw new Error('当前定义未选择 Jev。');
  const response = await requestJev(runtime.buildJevRequest(machine, record, context), process.env.TYPESAFE_API_KEY || '');
  const result = runtime.interpretJev(machine, record, context, response, hash);
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
} catch (error) { process.stderr.write(error.message + '\n'); process.exitCode = 1; }
