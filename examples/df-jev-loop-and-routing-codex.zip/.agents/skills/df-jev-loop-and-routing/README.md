# Jev · 循环与条件分支

由 DecoupleFlow 0.5.0 生成的独立状态机 Skill。

将整个 `df-jev-loop-and-routing` 目录放入宿主的技能目录，在宿主中显式调用技能。关闭 DecoupleFlow 后仍可使用。

- Codex：个人的 `~/.agents/skills/` 或目标项目的 `.agents/skills/`；使用 `$df-jev-loop-and-routing`。
- Claude Code：个人的 `~/.claude/skills/` 或目标项目的 `.claude/skills/`；使用 `/df-jev-loop-and-routing`。
- GitHub Copilot：个人的 `~/.copilot/skills/` 或目标项目的 `.github/skills/`；请求使用 `df-jev-loop-and-routing` 技能。

状态机定义版本：1.0.0。外部工具、权限、上下文和等待能力由宿主提供。

独立 Jev 底层接口也保留在 scripts/decide.mjs；日常运行使用 run.mjs advance，可自动记录实例和更新展示。

运行与可视化请参见 references/execution.md。新任务 start，未完成任务 resume，完成后自动归档。需要 Node.js 18.18+。
